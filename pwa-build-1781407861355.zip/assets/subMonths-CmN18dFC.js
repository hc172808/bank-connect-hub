import{a as t}from"./addMonths-BWu0jvl2.js";function r(o,s){return t(o,-s)}export{r as s};
