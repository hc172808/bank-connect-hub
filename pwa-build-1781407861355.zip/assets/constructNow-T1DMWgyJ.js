import{c as t}from"./constructFrom-DWjd9ymD.js";function c(o){return t(o,Date.now())}export{c};
