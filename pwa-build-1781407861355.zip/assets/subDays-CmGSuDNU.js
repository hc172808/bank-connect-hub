import{a as r}from"./addDays-BJhm0Vbw.js";function t(a,s){return r(a,-s)}export{t as s};
