import{t as e}from"./toDate-qOSwr3PX.js";import{c as o}from"./constructFrom-DWjd9ymD.js";function c(a,r){const t=e(a);return isNaN(r)?o(a,NaN):(r&&t.setDate(t.getDate()+r),t)}export{c as a};
